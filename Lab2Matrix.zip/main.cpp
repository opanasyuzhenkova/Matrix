#include "matrix.h"
using namespace std;

int main()
{
    Matrix matrixA;
    matrixA.getMatrixFromFile("input.txt");
    Matrix matrixB(matrixA);
    matrixA.setElement(0, 1, -1);
    matrixA.print();
    std::cout<<"_________\n";
    matrixB.print();
    Matrix matrixC;
    matrixC = matrixA + matrixB;
    std::cout<<"_________\n";
    matrixC.print();
    return 0;
}
